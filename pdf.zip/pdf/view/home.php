<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        foreach($categories as $category){
         echo "<button><a href='?action=make_pdf&categoryId=" . $category['categoryID'] . "'> show products at" . $category['categoryName'] . " </a></button>";
        }
        ?>
    </body>
</html>
