  <?php
     session_start();
     //function on requrred pages 
     require '../model/database.php';
      require '../model/category_db.php';
     
     
     //default action 
     $action =filter_input(INPUT_POST, 'action');
     if($action == NULL){
         $action = filter_input(INPUT_GET, 'action');
         if($action==NULL){
             $action='show_home';
         }
     }
     
     switch($action){
         case "show_home":
         $categories= getCategories();
        include "../view/home.php";     
    
             break;
             
         case "make_pdf":
              $catId = filter_input(INPUT_GET, "categoryId", FILTER_UNSAFE_RAW);
             $products= getProductsByCategory($catId);
             //print_r($products);
             include "../view/show_pdf.php";
             break;
     
         
         default:
             echo "No valid action found";
     }
         