
<?php

function getCategories() {
    global $db; //get access to the global DB connection pointer
    $query = "SELECT * FROM categories ";
    $statement = $db->prepare($query);
    $statement->execute();
    $category = $statement->fetchAll();
    $statement->closeCursor();

    return $category;
}


  function getProductsByCategory($catId){
       Global $db;
       $query= "SELECT * FROM products WHERE categoryID=:category_id ORDER by productID";
       $statement = $db->prepare($query); 
       $statement->bindValue(':category_id', $catId);
      try { $statement->execute();}
     catch (PDOException $ex) {
         //ECHO "Connection Failure Error is " . $ex->getMesssage();
         //redirect to an error page passing the error message
           header("Location:../view/error.php?msg=" . $ex->getMessage());
       }
       $products = $statement->fetchAll();
       $statement->closeCursor();
       return $products;
   }
?>
   